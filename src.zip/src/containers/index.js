export { default as Create } from './create/Create';
export { default as Dashboard } from './dashboard/Dashboard';
export { default as Landing } from './landing/Landing';
export { default as Login } from './login/Login';
export { default as Register } from './register/Register';
export { default as Status } from './status/Status';
export { default as Exam } from './exam/Exam';
